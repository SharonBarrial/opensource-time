﻿namespace si730ebu20221c936.Inventory.Domain.Model.ValueObjects;

public enum EOperationMode
{
    ScheduleDriven,
    TemperatureDriven,
    HumidityDriven
}