﻿namespace si730ebu20221c936.Inventory.Domain.Model.Queries;

public record GetThingByIdQuery(int Id);