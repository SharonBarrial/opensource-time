package com.sportnet.platform.u202212721.shared.interfaces.rest.resources;

public record MessageResource(String message) {
}
