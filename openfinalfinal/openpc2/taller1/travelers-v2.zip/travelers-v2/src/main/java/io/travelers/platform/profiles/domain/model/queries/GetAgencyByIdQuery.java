package io.travelers.platform.profiles.domain.model.queries;

public record GetAgencyByIdQuery(Long id) {
}
