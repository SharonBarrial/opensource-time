package io.travelers.platform.profiles.domain.model.queries;

public record GetAllAgenciesQuery() {
}
