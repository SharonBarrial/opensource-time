package com.spotify.platform.u202317002.shared.interfaces.rest.resources;

public record MessageResource(String message) {
}
