package com.spotify.platform.u202317002.inventories.domain.models.valueobjets;

public enum Rhythms {
    Salsa,
    Cumbia,
    Merengue
}
