package com.spotify.platform.u202317002;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Si729pc2u202317002ApplicationTests {

	@Test
	void contextLoads() {
	}

}
