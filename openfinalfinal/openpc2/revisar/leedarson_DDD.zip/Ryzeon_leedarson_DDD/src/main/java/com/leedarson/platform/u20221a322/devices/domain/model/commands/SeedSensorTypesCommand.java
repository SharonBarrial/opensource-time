package com.leedarson.platform.u20221a322.devices.domain.model.commands;

/**
 * Created by Alex Avila Asto - A.K.A (Ryzeon)
 * Project: leedarson
 * Date: 12/06/24 @ 01:10
 */
public record SeedSensorTypesCommand() {
}
