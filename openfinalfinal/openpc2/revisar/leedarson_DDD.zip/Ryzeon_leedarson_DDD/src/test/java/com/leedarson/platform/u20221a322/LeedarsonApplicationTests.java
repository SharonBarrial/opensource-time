package com.leedarson.platform.u20221a322;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeedarsonApplicationTests {

    @Test
    void contextLoads() {
    }

}
