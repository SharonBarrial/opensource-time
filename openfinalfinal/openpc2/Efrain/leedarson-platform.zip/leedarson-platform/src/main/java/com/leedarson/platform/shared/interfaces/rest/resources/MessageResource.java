package com.leedarson.platform.shared.interfaces.rest.resources;

public record MessageResource(String message) {
}
