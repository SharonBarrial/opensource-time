package com.leedarson.platform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeedarsonPlatformApplicationTests {

    @Test
    void contextLoads() {
    }

}
