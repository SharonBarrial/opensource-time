import { Component } from '@angular/core';

@Component({
  selector: 'app-the-home-content',
  standalone: true,
  imports: [],
  templateUrl: './the-home-content.component.html',
  styleUrl: './the-home-content.component.css'
})
export class TheHomeContentComponent {

}
