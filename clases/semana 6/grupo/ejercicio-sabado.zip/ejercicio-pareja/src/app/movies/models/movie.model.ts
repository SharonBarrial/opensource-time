export interface Movie {
  id: string;
  name: string;
  image: string;
  duration: string;
  genre: string;
}
