package com.acme.center.platform.learning.domain.model.valueobjects;

public enum EnrollmentStatus {
    REQUESTED,
    CONFIRMED,
    REJECTED,
    CANCELLED,
}
