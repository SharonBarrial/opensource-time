package com.acme.center.platform.learning.interfaces.rest.resources;

public record LearningPathItemResource(Long learningPathItemId, Long courseId, Long tutorialId) {
}