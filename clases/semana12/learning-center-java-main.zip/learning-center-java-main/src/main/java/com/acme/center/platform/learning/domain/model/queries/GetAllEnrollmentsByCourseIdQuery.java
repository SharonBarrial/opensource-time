package com.acme.center.platform.learning.domain.model.queries;

public record GetAllEnrollmentsByCourseIdQuery(Long courseId) {
}
