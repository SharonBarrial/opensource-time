package com.acme.center.platform.learning.domain.model.queries;

public record GetLearningPathItemByCourseIdAndTutorialIdQuery(Long courseId, Long tutorialId) {
}
