package com.acme.center.platform.learning.interfaces.rest.resources;

public record CreateCourseResource(String title, String description) {
}