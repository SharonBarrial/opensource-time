package com.acme.center.platform.learning.domain.model.valueobjects;

public enum ProgressStatus {
    NOT_STARTED,
    STARTED,
    COMPLETED,
}
