package com.acme.center.platform.learning.interfaces.rest.resources;

public record CourseResource(Long id, String title, String description) {
}