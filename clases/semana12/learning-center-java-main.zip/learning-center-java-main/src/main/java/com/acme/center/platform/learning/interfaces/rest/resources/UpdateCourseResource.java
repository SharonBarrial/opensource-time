package com.acme.center.platform.learning.interfaces.rest.resources;

public record UpdateCourseResource(String title, String description) {
}