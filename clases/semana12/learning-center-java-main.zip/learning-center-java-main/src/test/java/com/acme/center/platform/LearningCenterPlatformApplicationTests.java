package com.acme.center.platform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningCenterPlatformApplicationTests {

    @Test
    void contextLoads() {
    }

}
