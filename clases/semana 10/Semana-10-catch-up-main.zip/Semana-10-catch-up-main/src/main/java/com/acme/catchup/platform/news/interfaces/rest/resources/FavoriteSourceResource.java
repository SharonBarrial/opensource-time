package com.acme.catchup.platform.news.interfaces.rest.resources;

public record FavoriteSourceResource(Long id, String newsApiKey, String sourceId) { }
