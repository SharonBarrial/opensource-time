/**
 * FavoriteSource aggregate.
 *
 * @summary
 * The FavoriteSource class is an aggregate root that represents a favorite news source.
 * It is responsible for handling the CreateFavoriteSourceCommand command.
 */
package com.acme.catchup.platform.news.domain.model.aggregates;

import com.acme.catchup.platform.news.domain.model.commands.CreateFavoriteSourceCommand;
import jakarta.persistence.*;
import lombok.Getter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.domain.AbstractAggregateRoot;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.util.Date;

/**
 * FavoriteSource aggregate.
 *
 * <p>The FavoriteSource class is an aggregate root that represents a favorite news source.
 * It is responsible for handling the CreateFavoriteSourceCommand command.</p>
 */

@Entity
@EntityListeners(AuditingEntityListener.class) // it is used to automatically populate the createdAt and updatedAt fields
public class FavoriteSource extends AbstractAggregateRoot<FavoriteSource> {
    /** The unique identifier of the favorite source. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Getter
    private Long id;

    /** The API key for the news source. */
    @Column(nullable = false)
    @Getter
    private String newsApiKey;

    /** The identifier of the news source. */
    @Column(nullable = false)
    @Getter
    private String sourceId;

    /** The date and time when the favorite source was created. */
    @CreatedDate
    @Column(nullable = false, updatable = false)
    private Date createdAt;

    /** The date and time when the favorite source was last updated. */
    @LastModifiedDate
    @Column(nullable = false)
    private Date updatedAt;

    /**
     * Protected no-arg constructor for JPA.
     */
    protected FavoriteSource() {}

    /**
     * Constructor.
     * It creates a new FavoriteSource instance.
     *
     * @param command the CreateFavoriteSourceCommand command containing the details of the favorite source
     */
    public FavoriteSource(CreateFavoriteSourceCommand command) {
        this.newsApiKey = command.newsApiKey();
        this.sourceId = command.sourceId();
    }
}
