package pe.edu.pc.wx52.u202114900catchupplatform.news.domain.model.aggregates;

public class FavoriteSource {
}
