package pe.edu.pc.wx52.u202114900catchupplatform.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.pc.wx52.u202114900catchupplatform.model.Book;
import pe.edu.pc.wx52.u202114900catchupplatform.repository.BookRepository;
import pe.edu.pc.wx52.u202114900catchupplatform.service.BookService;

@Service
public class BookServiceImpl implements BookService {

    @Autowired
    private BookRepository bookRepository;

    public Book save(Book book)
    {
        return bookRepository.save(book);
    }
}
