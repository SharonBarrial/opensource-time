package pe.edu.pc.wx52.u202114900catchupplatform.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.pc.wx52.u202114900catchupplatform.model.Book;

import java.util.List;

public interface BookRepository extends JpaRepository<Book, Long> {


    List<Book> findByEditorial(String editorial);

    boolean existsByTitleAndEditorial(String title, String editorial);
}
