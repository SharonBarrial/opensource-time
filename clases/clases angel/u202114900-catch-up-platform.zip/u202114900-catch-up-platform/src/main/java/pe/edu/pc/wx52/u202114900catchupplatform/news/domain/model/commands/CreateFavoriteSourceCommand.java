package pe.edu.pc.wx52.u202114900catchupplatform.news.domain.model.commands;

public class CreateFavoriteSourceCommand {
}
