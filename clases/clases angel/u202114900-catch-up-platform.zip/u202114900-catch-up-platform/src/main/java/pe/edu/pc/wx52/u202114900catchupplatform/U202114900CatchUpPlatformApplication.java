package pe.edu.pc.wx52.u202114900catchupplatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class U202114900CatchUpPlatformApplication {

    public static void main(String[] args) {
        SpringApplication.run(U202114900CatchUpPlatformApplication.class, args);
    }

}
