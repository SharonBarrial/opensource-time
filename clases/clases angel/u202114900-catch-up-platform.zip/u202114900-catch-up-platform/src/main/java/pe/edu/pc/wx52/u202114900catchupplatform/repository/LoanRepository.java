package pe.edu.pc.wx52.u202114900catchupplatform.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.pc.wx52.u202114900catchupplatform.model.Book;
import pe.edu.pc.wx52.u202114900catchupplatform.model.Loan;

import java.util.List;

public interface LoanRepository extends JpaRepository<Loan, Long> {


    List<Loan> findByCodeStudent(String codeStudent);


    boolean existsByCodeStudentAndBookAndBookLoan(String codeStudent, Book book, boolean bookLoan);

}
