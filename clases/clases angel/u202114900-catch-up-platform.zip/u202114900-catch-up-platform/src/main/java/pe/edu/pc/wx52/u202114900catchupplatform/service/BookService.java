package pe.edu.pc.wx52.u202114900catchupplatform.service;

import pe.edu.pc.wx52.u202114900catchupplatform.model.Book;

public interface BookService {

    public abstract Book save(Book book);

}
