package pe.edu.pc.wx52.u202114900catchupplatform.exception;

public class ValidationException extends RuntimeException {
    public ValidationException(String message) {
        super(message);
    }

}
