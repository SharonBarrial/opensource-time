package pe.edu.pc.wx52.u202114900catchupplatform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class U202114900CatchUpPlatformApplicationTests {

    @Test
    void contextLoads() {
    }

}
