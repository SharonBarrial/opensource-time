# Getting Started

### Before Started
#### Steps for create a project 
###### Crear proyecto en Intelij IDEA
- En new project seleccionar Sprint Boot
- Nombre y ruta correcta (create git repository)
- Language: Java
- Type: Maven
- Group: com.acme
- Artifact: el mismo que el nombre
- Package name: (agregar .)  para diferenciar com.acme.catchup.platform
- JDK: openjdk-22
- Java:22
- Packaging: Jar

###### Configuración
- Seleccionar: Spring Boot: 3.2.5
- Developer Tools: Spring Boot DevTools, Lombok
- Web: Spring Web
- SQL: Spring Data JPA, MySQL Driver
- I/O: Validation

##### **CLICK EN CREATE**

----------------    

## Summary
This project is a simple REST API that expands 
the experience of CatchUp application, 
the News API client app, with the possibility 
of saving favorite news sources. It is implemented 
with Java Language, Spring Boot Framework, Spring Data JPA ORM Library, and MySQL database. 
It also illustrates Domain-Driven Design approach 
with tactical patterns.

### Reference Documentation

For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/3.2.5/maven-plugin/reference/html/)
* [Create an OCI image](https://docs.spring.io/spring-boot/docs/3.2.5/maven-plugin/reference/html/#build-image)
* [Spring Data JPA](https://docs.spring.io/spring-boot/docs/3.2.5/reference/htmlsingle/index.html#data.sql.jpa-and-spring-data)
* [Spring Boot DevTools](https://docs.spring.io/spring-boot/docs/3.2.5/reference/htmlsingle/index.html#using.devtools)
* [Validation](https://docs.spring.io/spring-boot/docs/3.2.5/reference/htmlsingle/index.html#io.validation)
* [Spring Web](https://docs.spring.io/spring-boot/docs/3.2.5/reference/htmlsingle/index.html#web)

### Guides

The following guides illustrate how to use some features concretely:

* [Accessing Data with JPA](https://spring.io/guides/gs/accessing-data-jpa/)
* [Accessing data with MySQL](https://spring.io/guides/gs/accessing-data-mysql/)
* [Validation](https://spring.io/guides/gs/validating-form-input/)
* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)

