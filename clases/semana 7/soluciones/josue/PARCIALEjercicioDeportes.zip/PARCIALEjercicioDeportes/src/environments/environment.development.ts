export const environment = {
  production: false,
  serverBasePath: 'http://localhost:3000/api/v1'
};
