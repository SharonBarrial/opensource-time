export const environment = {
  serverBasePath: undefined
};
