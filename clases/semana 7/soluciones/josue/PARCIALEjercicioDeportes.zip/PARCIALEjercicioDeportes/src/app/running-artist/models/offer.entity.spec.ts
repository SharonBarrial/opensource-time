// @ts-ignore
import { OfferEntity } from './offer.entity';

describe('OfferEntity', () => {
  it('should create an instance', () => {
    expect(new OfferEntity()).toBeTruthy();
  });
});
