import { BaseService } from './base.service';

describe('BaseService', () => {
  it('should create an instance', () => {
    // @ts-ignore
    expect(new BaseService()).toBeTruthy();
  });
});
