namespace WebmasterAPI.UserManagement.Authorization.Settings;

public class AppSettings
{
    public string Secret { get; set; } = "WeBmAsTeR@2024-01WeBmAsTeR@2024-01";
}