namespace WebmasterAPI.Authentication.Domain.Services.Communication;

public class UpdateRequest
{
    public string Email { get; set; }
    public string Password { get; set; }
}