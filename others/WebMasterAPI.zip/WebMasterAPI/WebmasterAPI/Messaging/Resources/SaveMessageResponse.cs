﻿namespace WebmasterAPI.Messaging.Resources
{
    public class SaveMessageResponse
    {
    }
}
