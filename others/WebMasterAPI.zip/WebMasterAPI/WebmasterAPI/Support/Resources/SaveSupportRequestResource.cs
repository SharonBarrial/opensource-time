﻿namespace WebmasterAPI.Support.Resources
{
    public class SaveSupportRequestResource
    {
        public int UserId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
    }
}
