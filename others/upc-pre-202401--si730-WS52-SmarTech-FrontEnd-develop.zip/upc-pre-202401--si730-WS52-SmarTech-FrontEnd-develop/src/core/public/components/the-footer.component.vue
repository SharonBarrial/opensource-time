<script setup>

</script>

<template>
  <div class="footer-component">
    <footer>
      <h5>{{ $t('copyright')}}</h5>

    </footer>
  </div>
</template>

<style scoped>
.footer-component{
  background: linear-gradient(180deg, rgb(138, 150, 197) 0%, rgb(255, 255, 255) 100%);
  color: #000000;
  padding: 50px;
  text-align: center;
  margin-top: 20px;
}
</style>