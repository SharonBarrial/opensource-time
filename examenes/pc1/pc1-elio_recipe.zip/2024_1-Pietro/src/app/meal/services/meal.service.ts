import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MealService {
  private _baseUrl = environment.baseURL;

  constructor(private _http: HttpClient) {}

  getRandomMeal() {
    return this._http.get(`${this._baseUrl}/v1/1/random.php`);
  }

  searchMealsByFirstLetter(letter: string) {
    return this._http.get(`${this._baseUrl}/v1/1/search.php?f=${letter}`);
  }

}
