import { Component } from '@angular/core';
import {HttpClientModule} from "@angular/common/http";

import { MealService } from '../../services/meal.service';

import {MatFormField} from "@angular/material/form-field";
import {MatInputModule} from "@angular/material/input";
import {MatCardModule} from "@angular/material/card";

@Component({
  selector: 'app-meal-search',
  standalone: true,
  imports: [
    HttpClientModule,

    MatFormField,
    MatInputModule,
    MatCardModule
  ],
  templateUrl: './meal-search.component.html',
  styleUrl: './meal-search.component.css'
})
export class MealSearchComponent {
  searchResults: any[] = [];

  constructor(private _mealService: MealService) {}

  searchMealsByInstructions(instructionKeyword: string) {
    // this._mealService.searchMealsByFirstLetter('a').subscribe({
    //   next: (response: any) => {
    //     this.searchResults = response.meals.filter((meal: any) =>
    //       meal.strInstructions.toLowerCase().includes(instructionKeyword.toLowerCase()));
    //   },
    //   error: (error: any) => console.error('Error fetching meals:', error)
    // });

    const alphaNum = 'abcdefghijklmnopqrstuvwxyz0123456789%+';
    const promises = [];

    for (const letter of alphaNum) {
      promises.push(this._mealService.searchMealsByFirstLetter(letter).toPromise());
    }

    Promise.all(promises).then(responses => {
      // @ts-ignore
      const allMeals = responses.flatMap(response => response.meals || []);
      this.searchResults = allMeals.filter((meal: any) =>
        meal.strInstructions.toLowerCase().includes(instructionKeyword.toLowerCase())
      );
    }).catch(error => {
      console.error('Error fetching meals:', error);
    });
  }

}
