import { Component, OnInit } from '@angular/core';
import { HttpClientModule } from "@angular/common/http";

import {MealSearchComponent} from "../meal-search/meal-search.component";
import { MealService } from '../../services/meal.service';

import {MatCardModule} from "@angular/material/card";

@Component({
  selector: 'app-meal-card',
  standalone: true,
  imports: [
    HttpClientModule,

    MealSearchComponent,

    MatCardModule
  ],
  templateUrl: './meal-card.component.html',
  styleUrl: './meal-card.component.css'
})
export class MealCardComponent implements OnInit {
  meal: any = ''

  constructor(
    private _mealService: MealService
  ) {}

  ngOnInit() {
    this.getRandomMeal()
  }

  getRandomMeal() {
    this._mealService.getRandomMeal().subscribe((res: any) =>
      {
        this.meal = res.meals[0]
      }
    )
  }

}
