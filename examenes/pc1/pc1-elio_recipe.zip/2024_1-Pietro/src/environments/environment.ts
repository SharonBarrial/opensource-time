export const environment = {
  production: false,
  baseURL: 'https://www.themealdb.com/api/json'
}
