import { Component } from '@angular/core';

@Component({
  selector: 'app-the-footer-component',
  standalone: true,
  imports: [],
  templateUrl: './the-footer-component.component.html',
  styleUrl: './the-footer-component.component.css'
})
export class TheFooterComponentComponent {

}
