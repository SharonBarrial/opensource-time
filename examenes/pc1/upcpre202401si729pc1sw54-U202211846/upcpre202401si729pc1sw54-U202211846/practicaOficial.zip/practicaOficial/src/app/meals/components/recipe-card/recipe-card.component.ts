import {Component, OnInit} from '@angular/core';
import {MatCardModule} from '@angular/material/card';
import {MatFormFieldModule} from "@angular/material/form-field";
import {MatInput} from "@angular/material/input";
import {HttpDataService} from "../../services/http-data.service";

@Component({
  selector: 'app-recipe-card',
  standalone: true,
  imports: [
    MatCardModule,
    MatFormFieldModule,
    MatInput
  ],
  templateUrl: './recipe-card.component.html',
  styleUrl: './recipe-card.component.css'
})
export class RecipeCardComponent implements OnInit {
  mealName: string = 'Meal Name';
  mealInstructions: string = 'Meal Instructions';
  mealFirstIngredient: string = 'Meal First Ingredient';
  mealSecondIngredient: string = 'Meal Second Ingredient';
  mealCategory: string = 'Meal Category';
  mealImage: string = 'Meal Image';

  constructor(private recipeService: HttpDataService) {
  }

  ngOnInit() {
    this.getMeal();
  }

  applyFilter(event: Event) {
    const inputElement = event.target as HTMLInputElement;
    const filteredValue = inputElement.value.replace(/[^a-zA-Z ]/g, '');
    this.getMealByName(filteredValue);
  }

  getMeal() {
    this.recipeService.getRandomMeal().subscribe(res => {
      this.mealName = res.meals[0].strMeal;
      this.mealInstructions = res.meals[0].strInstructions;
      this.mealFirstIngredient = res.meals[0].strIngredient1;
      this.mealSecondIngredient = res.meals[0].strIngredient2;
      this.mealCategory = res.meals[0].strCategory;
      this.mealImage = res.meals[0].strMealThumb;
    }, error => {
      console.log(error);
    });
  }

  getMealByName(name: string) {
    this.recipeService.getMealByName(name).subscribe(res => {
      this.mealName = res.meals[0].strMeal;
      this.mealInstructions = res.meals[0].strInstructions;
      this.mealFirstIngredient = res.meals[0].strIngredient1;
      this.mealSecondIngredient = res.meals[0].strIngredient2;
      this.mealCategory = res.meals[0].strCategory;
      this.mealImage = res.meals[0].strMealThumb;
    }, error => {
      console.log(error);
    });
  }
}
