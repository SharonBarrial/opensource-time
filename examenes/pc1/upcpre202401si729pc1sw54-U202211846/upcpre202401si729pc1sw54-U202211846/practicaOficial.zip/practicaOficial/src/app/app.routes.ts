import { Routes } from '@angular/router';
import {RecipeCardComponent} from "./meals/components/recipe-card/recipe-card.component";

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo:'recipes'},
  { path: 'recipes', component: RecipeCardComponent},
];
