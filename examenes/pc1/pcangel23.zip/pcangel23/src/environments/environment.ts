export const environment = {
  production: false,
  baseUrl: 'https://api.chucknorris.io/jokes/',
}
