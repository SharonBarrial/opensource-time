export class JokeModel {
  public id:any;
  public value:any;
  public category:any;
  constructor(id:any,value:any,category:any) {
    this.id=id;
    this.value=value;
    this.category=category;

  }
}
