import { Component } from '@angular/core';

@Component({
  selector: 'app-the-footer-content',
  standalone: true,
  imports: [],
  templateUrl: './the-footer-content.component.html',
  styleUrl: './the-footer-content.component.css'
})
export class TheFooterContentComponent {

}
