export class Character {
  image:any;
  name: any;
  species: any;
  status:any;
  location:any;
  constructor(image:any, name: any, species: any, status: any, location: any) {
    this.image = image;
    this.name = name;
    this.species = species;
    this.status = status;
    this.location = location;
  }
}
