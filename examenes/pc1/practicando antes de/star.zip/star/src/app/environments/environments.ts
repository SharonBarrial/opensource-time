// src/environments/environments.ts
export const environment = {
  production: false,
  apiUrl: 'https://swapi.dev/api/'
};
