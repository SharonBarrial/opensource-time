// src/app/app.module.ts
import { StarModule } from './star/star.module';
// ... Otras importaciones.

@NgModule({
  declarations: [
    // ... Tus otros componentes.
  ],
  imports: [
    StarModule,
    // ... Tus otros módulos.
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
