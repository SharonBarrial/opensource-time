// src/app/star/model/star-wars-item.model.ts
export interface StarWarsItem {
  name: string; // Asumiendo que cada elemento tiene un nombre, ajusta según los datos.
  // ... define aquí otros campos relevantes.
}
