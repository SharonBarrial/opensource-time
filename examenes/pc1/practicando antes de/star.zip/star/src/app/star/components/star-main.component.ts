// src/app/star/components/star-main/star-main.component.ts
import { Component, OnInit } from '@angular/core';
import { StarWarsService } from '../service/star-wars.service';

@Component({
  selector: 'app-star-main',
  templateUrl: './star-main.component.html',
  styleUrls: ['./star-main.component.css']
})
export class StarMainComponent implements OnInit {
  data: any = [];

  constructor(private starWarsService: StarWarsService) {}

  ngOnInit(): void {
    this.starWarsService.getPlanets().subscribe(response => {
      this.data = response.results; // Ajusta según la estructura de la respuesta.
    });
  }
}

