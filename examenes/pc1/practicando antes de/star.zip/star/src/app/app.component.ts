// src/app/star/star.module.ts
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StarMainComponent } from './components/star-main/star-main.component';
import { StarWarsService } from './service/star-wars.service';
import { MatToolbarModule } from '@angular/material/toolbar';

@NgModule({
  declarations: [StarMainComponent],
  imports: [
    CommonModule,
    MatToolbarModule,
    // ... Otros módulos de Material que necesites.
  ],
  providers: [StarWarsService]
})
export class StarModule { }

