import { Injectable } from '@angular/core';
import {environment} from "../../environment/environment";
import {HttpClient} from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class StarWarsService {
  baseUrl: string= environment.baseUrl;

  constructor(private http: HttpClient) { }

  getAllPlanets(){
    return this.http.get(environment.baseUrl );
  }
}
