import {Component, OnInit} from '@angular/core';
import {MatTableDataSource, MatTableModule} from "@angular/material/table";
import {StarWarsService} from "../../services/star-wars.service";

@Component({
  selector: 'app-table-planet',
  standalone: true,
  imports: [
    MatTableModule
  ],
  templateUrl: './table-planet.component.html',
  styleUrl: './table-planet.component.css'
})
export class TablePlanetComponent implements OnInit {

  displayedColumns: string[] = ['name', 'rotation_period', 'orbital_period', 'diameter'
  ,'climate','gravity','terrain','surface_water','population','created'];

  ngOnInit() {
    this.getPlanets()
  }
  dataSource:any;
  constructor(private starsService: StarWarsService) {
  }

  getPlanets(){
    this.starsService.getAllPlanets().subscribe((data: any) => {
      console.log(data.results);
      this.dataSource = data.results;
    })
  }
}
