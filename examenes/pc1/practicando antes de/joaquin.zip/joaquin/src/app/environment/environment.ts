export const environment = {
  production: false,
  baseUrl: 'https://swapi.dev/api/planets/?format=json',
}
