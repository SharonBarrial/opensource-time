import { Cocktail } from './cocktail.model';

describe('Cocktail', () => {
  it('should create an instance', () => {
    expect(new Cocktail()).toBeTruthy();
  });
});
