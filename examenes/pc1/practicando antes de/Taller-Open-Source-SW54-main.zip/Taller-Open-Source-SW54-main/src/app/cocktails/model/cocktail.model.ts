export class Cocktail {
  private name:any;
  private instructions:any;
  private date:any;
  private glass:any;
  constructor(name:any, instructions:any, date:any, glass:any) {
    this.name = name;
    this.instructions = instructions;
    this.date = date;
    this.glass = glass;
  }

}
