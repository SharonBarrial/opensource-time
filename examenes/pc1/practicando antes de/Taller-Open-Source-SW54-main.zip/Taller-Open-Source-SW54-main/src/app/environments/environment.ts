export const environment = {
  production:false,
  baseUrl: "https://www.thecocktaildb.com/api/json/v1/1/search.php?f=a"
}
