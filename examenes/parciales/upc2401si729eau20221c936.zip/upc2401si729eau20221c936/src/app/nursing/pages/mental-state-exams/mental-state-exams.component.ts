import { Component } from '@angular/core';
import {MentalStateExams} from "../../models/mental-state-exams/mental-state-exams.entity";
import {Patients} from "../../models/patients/patients.entity";
import {Examiners} from "../../models/examiners/examiners.entity";
import {MentalStateExamsService} from "../../services/mental-state-exams/mental-state-exams.service";
import {PatientsService} from "../../services/patients/patients.service";
import {ExaminersService} from "../../services/examiners/examiners.service";

@Component({
  selector: 'app-mental-state-exams',
  templateUrl: './mental-state-exams.component.html',
  styleUrl: './mental-state-exams.component.css'
})
export class MentalStateExamsComponent {

  mentalStateExams: MentalStateExams[] = [];
  patients: Patients[] = [];
  examiners: Examiners[] = [];

  constructor(
    private mentalStateExamsService: MentalStateExamsService,
    private patientsService: PatientsService,
    private examinersService: ExaminersService
  ) { }

  ngOnInit(): void {
    this.getMentalStateExams();
    this.getPatients();
    this.getExaminers();
  }

  getMentalStateExams() {
    this.mentalStateExamsService.getAll()
      .subscribe((response: any) => {
        this.mentalStateExams = response;
      });
  }

  getPatients() {
    this.patientsService.getAll()
      .subscribe((response: any) => {
        this.patients = response;
      });
  }

  getExaminers() {
    this.examinersService.getAll()
      .subscribe((response: any) => {
        this.examiners = response;
      });
  }

  calculateTotalScore(exam: MentalStateExams): number {
    // Implement logic to calculate total score based on exam properties
    const scores = [
      exam.orientationScore,
      exam.registrationScore,
      exam.attentionAndCalculationScore,
      exam.recallScore,
      exam.languageScore
    ];
    return scores.reduce((acc, curr) => acc + curr, 0);
  }

  getPatientName(patientId: number): string {
    const patient = this.patients.find(p => p.id === patientId);
    return patient ? `${patient.firstName} ${patient.lastName}` : 'Patient Not Found';
  }

  getPatientBirthDate(patientId: number): string {
    const patient = this.patients.find(p => p.id === patientId);
    return patient ? patient.birthDate : '';
  }

  getExaminerName(examinerId: number): string {
    const examiner = this.examiners.find(e => e.id === examinerId);
    return examiner ? `${examiner.firstName} ${examiner.lastName}` : 'Examiner Not Found';
  }

  getExaminerNPI(examinerId: number): string {
    const examiner = this.examiners.find(e => e.id === examinerId);
    return examiner ? examiner.nationalProviderIdentifier : '';
  }

  getPatientPhotoUrl(patientId: number): string {
    const patient = this.patients.find(p => p.id === patientId);
    return patient ? patient.photoUrl : '';
  }
}
