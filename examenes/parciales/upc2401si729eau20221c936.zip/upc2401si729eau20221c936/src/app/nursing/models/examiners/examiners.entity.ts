export class Examiners {
  id: number;
  firstName: string;
  lastName: string;
  nationalProviderIdentifier: string;

  constructor() {
    this.id = 0;
    this.firstName = "";
    this.lastName = "";
    this.nationalProviderIdentifier = "";
  }
}
