import { MentalStateExams } from './mental-state-exams.entity';

describe('MentalStateExams', () => {
  it('should create an instance', () => {
    expect(new MentalStateExams()).toBeTruthy();
  });
});
