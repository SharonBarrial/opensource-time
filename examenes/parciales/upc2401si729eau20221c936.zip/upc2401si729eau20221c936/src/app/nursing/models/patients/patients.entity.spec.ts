import { Patients } from './patients.entity';

describe('Patients', () => {
  it('should create an instance', () => {
    expect(new Patients()).toBeTruthy();
  });
});
