import { Examiners } from './examiners.entity';

describe('Examiners', () => {
  it('should create an instance', () => {
    expect(new Examiners()).toBeTruthy();
  });
});
