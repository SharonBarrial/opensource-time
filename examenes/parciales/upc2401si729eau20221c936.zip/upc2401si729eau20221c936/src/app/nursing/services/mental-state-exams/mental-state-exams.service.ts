import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {BaseService} from "../../../shared/base.service";
import {MentalStateExams} from "../../models/mental-state-exams/mental-state-exams.entity";

@Injectable({
  providedIn: 'root'
})
export class MentalStateExamsService extends BaseService<MentalStateExams>{

  constructor(http: HttpClient) {
    super(http);
    this.resourceEndpoint = '/mental-state-exams'
  }
}
