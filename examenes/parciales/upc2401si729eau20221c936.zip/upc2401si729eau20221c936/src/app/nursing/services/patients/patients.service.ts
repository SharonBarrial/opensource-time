import { Injectable } from '@angular/core';
import {BaseService} from "../../../shared/base.service";
import {HttpClient} from "@angular/common/http";
import {Patients} from "../../models/patients/patients.entity";

@Injectable({
  providedIn: 'root'
})
export class PatientsService extends BaseService<Patients>{

  constructor(http: HttpClient) {
    super(http);
    this.resourceEndpoint = '/patients'
  }
}
