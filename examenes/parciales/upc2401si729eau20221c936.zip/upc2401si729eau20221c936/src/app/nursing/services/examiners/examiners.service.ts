import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {BaseService} from "../../../shared/base.service";
import {Examiners} from "../../models/examiners/examiners.entity";

@Injectable({
  providedIn: 'root'
})
export class ExaminersService extends BaseService<Examiners>{

  constructor(http: HttpClient) {
    super(http);
    this.resourceEndpoint = '/examiners'
  }
}
