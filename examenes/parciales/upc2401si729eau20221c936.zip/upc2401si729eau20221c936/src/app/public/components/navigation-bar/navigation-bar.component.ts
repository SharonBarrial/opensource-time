import {Component, OnInit} from '@angular/core';
import {TranslateService} from "@ngx-translate/core";

@Component({
  selector: 'app-navigation-bar',
  templateUrl: './navigation-bar.component.html',
  styleUrl: './navigation-bar.component.css'
})
export class NavigationBarComponent implements OnInit {
  options = [
    {path: '/home', title: 'Home'},
    {path: '/nursing/mental-state-exams', title: 'Mental State Exams'},
  ]
  public translateService: TranslateService; // Made public

  constructor(translateService: TranslateService) {
    this.translateService = translateService;
  }
  ngOnInit() { }

  changeLanguage(): void {
    const newLang = this.translateService.currentLang === 'en' ? 'es' : 'en';
    this.translateService.use(newLang);
  }
}
