import {Component, OnInit} from '@angular/core';
import {TranslateService} from "@ngx-translate/core";

@Component({
  selector: 'app-home-section',
  templateUrl: './home-section.component.html',
  styleUrl: './home-section.component.css'
})
export class HomeSectionComponent implements OnInit{

  heroSectionPhrase: string ='';

  constructor(private translateService: TranslateService) { }

  ngOnInit() {
    // Set default language (optional)
    this.translateService.use('en');

    // Get translations from JSON
    this.translateService.get('heroSectionPhrase').subscribe((translatedPhrase: string) => {
      this.heroSectionPhrase = translatedPhrase;
    });
  }
}
