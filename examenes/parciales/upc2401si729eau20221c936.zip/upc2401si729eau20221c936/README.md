# Aplicación de I18n para el Hero Section

Esta aplicación implementa la internacionalización (i18n) para el Hero Section de un sitio web, utilizando Angular y la biblioteca @ngx-translate/core. Permite mostrar el texto del Hero Section en diferentes idiomas, según la configuración del usuario.

Para el correcto funcionamiento del código, se deben de instalar en el terminal los siguientes comandos:

```
npm i
ng add @angular/material
npm i json-server
npm i @ngx-translate/core
```

# Características:

Carga de traducciones desde archivos JSON.
Inyección del servicio TranslateService para acceder a las traducciones.
Uso de la directiva translate en el HTML para mostrar el texto traducido.
Cambio dinámico del idioma mediante el servicio TranslateService.

# Autor:

Nombre: Pescoran Angulo, Juan Fabritzzio
Código de Alumno: u20221c936
