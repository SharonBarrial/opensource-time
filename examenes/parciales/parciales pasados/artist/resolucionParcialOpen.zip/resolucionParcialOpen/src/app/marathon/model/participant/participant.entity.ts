export class Participant {
  id: number;
  firstName: string;
  lastName: string;
  photoUrl: string;
  centerId: number;
  ranking: number;
  recordTime: string;
  centerName:string;

  constructor() {
    this.id = 1;
    this.firstName = '';
    this.lastName = '';
    this.photoUrl = '';
    this.centerId = 1;
    this.ranking = 1;
    this.recordTime = '';
    this.centerName = '';
  }
}
