import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MarathonGridComponent } from './marathon-grid.component';

describe('MarathonGridComponent', () => {
  let component: MarathonGridComponent;
  let fixture: ComponentFixture<MarathonGridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MarathonGridComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(MarathonGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
