import { PublicationEntity } from './publication.entity';

describe('PublicationEntity', () => {
  it('should create an instance', () => {
    expect(new PublicationEntity()).toBeTruthy();
  });
});
