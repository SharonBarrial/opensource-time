import {Component, OnInit} from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {MatTableDataSource} from "@angular/material/table";
import {Student} from "../../model/students/student.entity";
import {SingUp} from "../../model/sing-up/sing-up.entity";
import {StudentProfile} from "../../model/students-profile/student-profile.entity";
import {CreateAccountService} from "../../services/create-account-api/create-account.service.service";
import {Router} from "@angular/router";
import {StudentsProfileService
} from "../../services/student-profile-api/students-profile.service.service";
import {StudentsService} from "../../services/student-api-service/students.service";

@Component({
  selector: 'app-register-manager',
  templateUrl: './register-manager.component.html',
  styleUrl: './register-manager.component.css'
})
export class RegisterManagerComponent implements OnInit{
  email: string = "";
  lastName: string = "";
  phoneNumber: string = "";
  firstName: string = "";

  myForm: FormGroup = new FormGroup({
    userName: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required),
    email: new FormControl('',[ Validators.required,Validators.email]), // Agregar control para el email
    phoneNumber: new FormControl('', Validators.required),
    lastName: new FormControl('', Validators.required),
    firstName: new FormControl('', Validators.required),
  });
  singUp :SingUp ;
  student: Student;
  studentProfile: StudentProfile;
  dataSource: MatTableDataSource<any>;

  constructor(
    private createAccountService: CreateAccountService,
    private studentProfileService: StudentsProfileService,
    private router: Router,
    private studentService: StudentsService
  ) {
    this.student = {} as Student;
    this.singUp = {} as SingUp;
    this.studentProfile = {} as StudentProfile;
    this.dataSource = new MatTableDataSource<any>();

  }
  ngOnInit(): void {
    this.singUp.roles= ["ROLE_USER"];
  }
  registerAccount(): void {
    if (this.myForm.valid) {
      this.singUp.id = 0;
      this.student.firstName = this.singUp.username;
      this.student.password = this.singUp.password;
      //translate data
      this.student.email = this.email;
      this.student.lastName = this.lastName;
      this.student.firstName = this.firstName;

      this.createAccountService.singUp(this.singUp).subscribe(
        (response: any) => {
          this.dataSource.data.push({...response});
          this.dataSource.data = this.dataSource.data.map((p: SingUp) => {
            console.log(p);

            //create student
            this.studentService.create(this.student).subscribe(
              (response: any) => {
                this.dataSource.data.push({...response});
                console.log(this.dataSource)
                this.dataSource.data = this.dataSource.data.map((p: Student) => {
                  console.log(p);
                  this.studentProfile.idStudent=p.id;


                  return p;
                });

                //translate data
                this.studentProfile.nick="";
                this.studentProfile.phoneNumber=this.phoneNumber;
                this.studentProfile.slogan="";
                this.studentProfile.userProfilePhoto="";
                //create student profile
                this.studentProfileService.create(this.studentProfile).subscribe();
                alert("user created")
              },
              (error) => {
                console.error('Error en la solicitud:', error);
              }
            );


            this.router.navigate(['/']);
            return p;
          });
        },
        (error) => {
          console.error('Error en la solicitud:', error);
        }
      );
    } else {
      alert('Por favor complete todos los campos obligatorios');
    }
  }

}
