import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MarathonWinnerCardComponent } from './marathon-winner-card.component';

describe('MarathonWinnerCardComponent', () => {
  let component: MarathonWinnerCardComponent;
  let fixture: ComponentFixture<MarathonWinnerCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MarathonWinnerCardComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(MarathonWinnerCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
