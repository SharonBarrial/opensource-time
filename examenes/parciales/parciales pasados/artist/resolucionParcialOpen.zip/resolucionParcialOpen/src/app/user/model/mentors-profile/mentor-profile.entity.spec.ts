import { MentorProfileEntity } from './mentor-profile.entity';

describe('MentorProfileEntity', () => {
  it('should create an instance', () => {
    expect(new MentorProfileEntity()).toBeTruthy();
  });
});
