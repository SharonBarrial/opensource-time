import {Component, OnInit} from '@angular/core';
import {Participant} from "../../model/participant/participant.entity";
import {ParticipantsService} from "../../services/api-participant/participants.service";

@Component({
  selector: 'app-marathon-grid',
  templateUrl: './marathon-grid.component.html',
  styleUrl: './marathon-grid.component.css'
})
export class MarathonGridComponent implements OnInit{
 resources:Array<Participant>= [];

 constructor(private participantApi:ParticipantsService) {
 }
  ngOnInit(): void {
    this.participantApi.getAll().subscribe(
      (data: any) => { this.resources=data;
        // Ordenar los datos en función del atributo recordTime

      }
    );
  }



}
