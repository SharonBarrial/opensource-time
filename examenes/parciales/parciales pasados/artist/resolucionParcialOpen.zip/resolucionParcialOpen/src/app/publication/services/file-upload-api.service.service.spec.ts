import { TestBed } from '@angular/core/testing';

import { FileUploadApiServiceService } from './file-upload-api.service.service';

describe('FileUploadApiServiceService', () => {
  let service: FileUploadApiServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FileUploadApiServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
