import { CenterEntity } from './center.entity';

describe('CenterEntity', () => {
  it('should create an instance', () => {
    expect(new CenterEntity()).toBeTruthy();
  });
});
