import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RecordsForMarathonIdComponent } from './records-for-marathon-id.component';

describe('RecordsForMarathonIdComponent', () => {
  let component: RecordsForMarathonIdComponent;
  let fixture: ComponentFixture<RecordsForMarathonIdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RecordsForMarathonIdComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(RecordsForMarathonIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
