import { StudentProfileEntity } from './student-profile.entity';

describe('StudentProfileEntity', () => {
  it('should create an instance', () => {
    expect(new StudentProfileEntity()).toBeTruthy();
  });
});
