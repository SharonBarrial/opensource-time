import {Component, OnInit} from '@angular/core';
import {Publication} from "../../../user/model/publications/publication.entity";
import {PublicationApiServiceService} from "../../services/publication-api.service.service";
import {ActivatedRoute, Router} from "@angular/router";

@Component({
  selector: 'app-publication-id',
  templateUrl: './publication-id.component.html',
  styleUrl: './publication-id.component.css'
})
export class PublicationIdComponent implements OnInit{
  idPublication: string|undefined;
  publication: Publication | undefined;
  liked: boolean = false;
  linkCount:number | undefined=0;
  viewCount:number | undefined=0;
  id: number=0;
  constructor(    private arquimentorService: PublicationApiServiceService,
                  private route: ActivatedRoute,private router: Router
  ) {


  }

  ngOnInit(): void {
    const publicationId = this.route.snapshot.params['id'];
    console.log('id: ',publicationId)

    this.idPublication = publicationId;
    this.arquimentorService.incrementView(publicationId).subscribe();
    this.getIdPublication(publicationId);
    const userLiked = localStorage.getItem('userLiked'+publicationId);
    this.liked = userLiked === 'true';
  }

  private getIdPublication(publicationId: number) {
    this.arquimentorService.getPublicationId(publicationId).subscribe((response: any) => {
      this.publication = response;
    //  this.linkCount= this.publication?.likes;
     // this.viewCount= this.publication?.views;
      // @ts-ignore
  //    this.viewCount= this.viewCount+1;
    });
  }

}
