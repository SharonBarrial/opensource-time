import { StudentEntity } from './student.entity';

describe('StudentEntity', () => {
  it('should create an instance', () => {
    expect(new StudentEntity()).toBeTruthy();
  });
});
