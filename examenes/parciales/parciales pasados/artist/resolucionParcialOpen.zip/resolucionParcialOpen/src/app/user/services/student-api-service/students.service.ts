import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {BaseService} from "../../../shared/services/base.service";
import {Student} from "../../model/students/student.entity";
import {catchError, retry} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class StudentsService extends BaseService<Student>{

  constructor(http: HttpClient) {
    super(http);
    this.resourceEndpoint = "/students";
  }
  getStudentByUserId(id: number): any {
    return this.http.get(`${this.resourcePath()}/${id}`, this.httpOptions)
      .pipe(retry(2), catchError(this.handleError));
  }
}
