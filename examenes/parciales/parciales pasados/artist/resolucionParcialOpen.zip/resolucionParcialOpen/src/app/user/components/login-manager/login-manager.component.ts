import { Component } from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {Student} from "../../model/students/student.entity";
import {SingIn} from "../../model/sing-in/sing-in.entity";
import {MatTableDataSource} from "@angular/material/table";
import {CreateAccountService} from "../../services/create-account-api/create-account.service.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-login-manager',
  templateUrl: './login-manager.component.html',
  styleUrl: './login-manager.component.css'
})
export class LoginManagerComponent {
  myForm: FormGroup = new FormGroup({
    userName: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required)
  });
  student: Student | undefined;
  singIn: SingIn;
  dataSource: MatTableDataSource<any>;
  constructor(
    private createAccountService: CreateAccountService,
    private router: Router
  ) {
    this.singIn = {} as SingIn;
    this.dataSource = new MatTableDataSource<any>();
  }


  singInAccount() {
    this.createAccountService.singIn(this.singIn).subscribe(
      (response: any) => {
        this.dataSource.data.push({...response});
        console.log(this.dataSource.data)
        this.dataSource.data = this.dataSource.data.map((p: SingIn) => {
          localStorage.setItem('token', p.token);

          alert("login iniciado")

          this.router.navigate(['home'],{ queryParams: { id: p.id } });
          return p;
        });
      },
      (error) => {
        console.error('Error en la solicitud:', error);
        alert("username or password incorrect")
      }
    );
  }

}
