import { Injectable } from '@angular/core';
import {BaseService} from "../../../shared/services/base.service";
import {SingUp} from "../../model/sing-up/sing-up.entity";

@Injectable({
  providedIn: 'root'
})
export class ClientProfileServiceService extends BaseService<SingUp>{

 // constructor() { }
}
