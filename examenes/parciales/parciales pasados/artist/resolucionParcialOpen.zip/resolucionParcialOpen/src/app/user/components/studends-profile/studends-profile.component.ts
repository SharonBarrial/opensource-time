import {Component, OnInit} from '@angular/core';
import {MatTableDataSource} from "@angular/material/table";
import {StudentProfile} from "../../model/students-profile/student-profile.entity";
import {ActivatedRoute} from "@angular/router";
import {FileUploadApiServiceService} from "../../../publication/services/file-upload-api.service.service";
import {StudentsProfileService} from "../../services/student-profile-api/students-profile.service.service";

@Component({
  selector: 'app-studends-profile',
  templateUrl: './studends-profile.component.html',
  styleUrl: './studends-profile.component.css'
})
export class StudendsProfileComponent  implements OnInit {
  userProfile: StudentProfile | undefined;
  isEditing = false;
  dataSource: MatTableDataSource<any>;
  idRouter:Number | undefined;
  images: any = [];
  urlImage: string | undefined;
  constructor(
    private studentProfileService: StudentsProfileService,
    public route: ActivatedRoute,
    private fileUploadService: FileUploadApiServiceService
  ){this.dataSource = new MatTableDataSource<any>();}

  toggleEdit(): void {
    // @ts-ignore
    if (this.userProfile.userProfilePhoto==""){
      // @ts-ignore
      this.userProfile.userProfilePhoto="https://cdn.discordapp.com/attachments/1149549726748921939/1175717928063225928/images.png?ex=656c3fa5&is=6559caa5&hm=d6a6935bf1b8eeff5f2ee6b0ad85786c82ac00b04cd78163e624fd62c17a01e1&"
    }
    this.isEditing = true;
  }
  ngOnInit(): void {
    const studentProfileId = this.route.snapshot.params['studentProfileId'];
    this.getStudentProfileId(studentProfileId);
    this.idRouter=studentProfileId;
  }
  saveProfile(): void {
    this.isEditing = false;
    if (this.urlImage != undefined) {
      // @ts-ignore
      this.userProfile.userProfilePhoto = this.urlImage;
    }

    this.studentProfileService.update(this.userProfile?.id,this.userProfile).subscribe(
      (response: any) => {
        this.dataSource.data.push({...response});
        console.log(this.dataSource)
        this.dataSource.data = this.dataSource.data.map((sp: StudentProfile) => {
          console.log(sp);
          alert("profile editado")
          //this.router.navigate(['/']);
          return sp;
        });
      },
      (error) => {
        console.error('Error en la solicitud:', error);
      }
    );
  }
  cancelEdit(): void {
    this.isEditing = false;
    // @ts-ignore
    this.studentProfileService.getStudentProfileId(this.idRouter).subscribe((response: any) => {
      this.userProfile = response;
    });
  }

  private getStudentProfileId(studentProfileId: number) {
    this.studentProfileService.getStudentProfileId(studentProfileId).subscribe((response: any) => {
      console.log(studentProfileId);
      this.userProfile = response;
      console.log(this.userProfile);
    });
  }



}
