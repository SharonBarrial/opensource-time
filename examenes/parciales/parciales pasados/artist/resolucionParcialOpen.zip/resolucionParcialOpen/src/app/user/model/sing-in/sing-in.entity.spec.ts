import { SingInEntity } from './sing-in.entity';

describe('SingInEntity', () => {
  it('should create an instance', () => {
    expect(new SingInEntity()).toBeTruthy();
  });
});
