import {Student} from "../students/student.entity";

export class Mentor {
  subscription: string;
  student: Student;
  idStudent: number;
  constructor() {
    this.subscription = '';
    this.student = new Student();
    this.idStudent=0;
  }
}
