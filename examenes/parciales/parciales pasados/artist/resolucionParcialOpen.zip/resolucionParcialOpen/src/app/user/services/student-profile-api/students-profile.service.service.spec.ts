import { TestBed } from '@angular/core/testing';

import { StudentsProfileService } from './students-profile.service.service';

describe('StudentsProfileServiceService', () => {
  let service: StudentsProfileService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StudentsProfileService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
