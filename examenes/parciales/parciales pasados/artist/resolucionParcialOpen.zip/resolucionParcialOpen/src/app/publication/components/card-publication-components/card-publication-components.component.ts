import {Component, Input, OnInit} from '@angular/core';
import {Publication} from "../../../user/model/publications/publication.entity";
import {ActivatedRoute, Router} from "@angular/router";

@Component({
  selector: 'app-card-publication-components',
  templateUrl: './card-publication-components.component.html',
  styleUrl: './card-publication-components.component.css'
})
export class CardPublicationComponentsComponent  implements OnInit{
  @Input() publications: Array<Publication>=[];
  id: number=0;
  constructor(private router:Router,
              private route: ActivatedRoute) {
   // this.route.queryParams.subscribe(params => {
     // this.id = params['id'];
//});
  }

  ngOnInit(): void {

  }

  seeIdPublication(id:number) {
    console.log(id)
    console.log('seeIdPublication(id: number)')
    this.router.navigate(['/publication',id])
  }
}
