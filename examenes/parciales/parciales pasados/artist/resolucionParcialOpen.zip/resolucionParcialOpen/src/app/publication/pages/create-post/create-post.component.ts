import { Component } from '@angular/core';
import {ThemePalette} from "@angular/material/core";
import {MatTableDataSource} from "@angular/material/table";
import {Publication} from "../../../user/model/publications/publication.entity";
import {ActivatedRoute, Router} from "@angular/router";
import {PublicationApiServiceService} from "../../services/publication-api.service.service";
import {FileUploadApiServiceService} from "../../services/file-upload-api.service.service";

@Component({
  selector: 'app-create-post',
  templateUrl: './create-post.component.html',
  styleUrl: './create-post.component.css'
})
export class CreatePostComponent {
  idUrl: string | undefined;
  isVisibilityOn: any;
  color: ThemePalette = "warn";
  checked = true;
  disabled = false;
  dataSource: MatTableDataSource<any>;
  publication: Publication;
  //imagen
  images: any = [];
  private Integer: any;

  constructor(private route: ActivatedRoute, private arquimentorService: PublicationApiServiceService, private router: Router, private fileUploadService: FileUploadApiServiceService) {
    this.publication = {} as Publication;
    this.dataSource = new MatTableDataSource<any>();

    this.publication.image = [];
    this.route.queryParams.subscribe(params => {
      this.idUrl = params['id'];
    });
    this.publication.mentorProfileId = Number(this.idUrl);
  }

  createPublication(): void {

    this.arquimentorService.create(this.publication).subscribe(
      (response: any) => {
        this.dataSource.data.push({...response});
        console.log(this.dataSource)
        this.dataSource.data = this.dataSource.data.map((p: Publication) => {
          console.log(p);
          alert("post created")
          this.router.navigate(["/home"],{ queryParams: { id: this.idUrl }});
          return p;

        });
      },
      (error) => {
        console.error('Error en la solicitud:', error);
      }
    );
  }

  onFileSelected(event: any): void {
    let archivoCapturado = event.target.files;

    for (let i = 0; i < archivoCapturado.length; i++) {
      let reader = new FileReader();
      reader.readAsDataURL(archivoCapturado[i]);

      reader.onloadend = () => {
        console.log(reader.result);
        this.images.push(reader.result);
        // @ts-ignore
        this.fileUploadService.submitImage(this.publication.id + " " + Date.now(), reader.result).then(urlImage => {
          console.log(urlImage);
          //asociar de una vez la imagen al post
          // @ts-ignore
          this.publication.image.push(urlImage);
        });
      }
    }
  }

  cancelEdit() {
    this.router.navigate(["/home"],{ queryParams: { id: this.idUrl } });
  }

}
