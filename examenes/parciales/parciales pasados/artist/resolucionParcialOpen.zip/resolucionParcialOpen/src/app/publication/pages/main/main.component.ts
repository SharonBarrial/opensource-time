import {Component, OnInit} from '@angular/core';
import {Publication} from "../../../user/model/publications/publication.entity";
import {Student} from "../../../learning/model/student.entity";
import {ActivatedRoute, Router} from "@angular/router";
import {PublicationApiServiceService} from "../../services/publication-api.service.service";
import {StudentsService} from "../../../user/services/student-api-service/students.service";

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrl: './main.component.css'
})
export class MainComponent implements OnInit{
  publicationsA: Array<Publication> = [];
  id: number=0;
  student: Student | undefined;
  constructor(private router:Router,
              private arquimentorService: PublicationApiServiceService,
              private studentService: StudentsService,
              private route: ActivatedRoute) {
    this.route.queryParams.subscribe(params => {
      this.id = params['id'];
    });
  }
  addPost(): void {
    this.router.navigate(['create-post'],{ queryParams: { id: this.id } });
  }

  ngOnInit(): void {
    this.arquimentorService.getAll().subscribe((response: any) => {
      this.publicationsA = response;
      console.log(this.publicationsA)
    });
    this.studentService.getStudentByUserId(this.id).subscribe((response: any) => {
      this.student = response;
    });
  }

}
