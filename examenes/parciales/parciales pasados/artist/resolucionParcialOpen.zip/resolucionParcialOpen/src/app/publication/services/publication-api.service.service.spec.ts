import { TestBed } from '@angular/core/testing';

import { PublicationApiServiceService } from './publication-api.service.service';

describe('PublicationApiServiceService', () => {
  let service: PublicationApiServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PublicationApiServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
