import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudendsProfileComponent } from './studends-profile.component';

describe('StudendsProfileComponent', () => {
  let component: StudendsProfileComponent;
  let fixture: ComponentFixture<StudendsProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [StudendsProfileComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(StudendsProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
