import { Component, Input } from '@angular/core';
import { Participant } from "../../model/participant/participant.entity";

@Component({
  selector: 'app-marathon-card',
  templateUrl: './marathon-card.component.html',
  styleUrls: ['./marathon-card.component.css'] // Corregido a styleUrls
})
export class MarathonCardComponent {

  @Input() resource: Participant = new Participant();
}
