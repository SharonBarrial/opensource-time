import { ParticipantEntity } from './participant.entity';

describe('ParticipantEntity', () => {
  it('should create an instance', () => {
    expect(new ParticipantEntity()).toBeTruthy();
  });
});
