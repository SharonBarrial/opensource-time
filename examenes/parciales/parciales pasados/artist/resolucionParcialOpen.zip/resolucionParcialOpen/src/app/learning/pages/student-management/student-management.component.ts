import {AfterViewInit, Component, OnInit, ViewChild} from '@angular/core';
import {Student} from "../../model/student.entity";
import {MatTableDataSource} from "@angular/material/table";
import {MatPaginator} from "@angular/material/paginator";
import {MatSort} from "@angular/material/sort";
import {StudentsService} from "../../../user/services/student-api-service/students.service";

@Component({
  selector: 'app-student-management',
  templateUrl: './student-management.component.html',
  styleUrl: './student-management.component.css'
})
export class StudentManagementComponent implements OnInit, AfterViewInit {

  // Attributes

  studentData: Student;
  dataSource!: MatTableDataSource<any>;
  displayedColumns: string[] = ['id', 'name', 'age', 'address', 'actions'];
  @ViewChild(MatPaginator, {static: false}) paginator!: MatPaginator;
  @ViewChild(MatSort, {static: false}) sort!: MatSort;
  isEditMode: boolean;

  // Constructor

  constructor(private studentService: StudentsService) {
    this.isEditMode = false;
    this.studentData = {} as Student;
    this.dataSource = new MatTableDataSource<any>();
  }

  // Private Methods

  private resetEditState(): void {
    this.isEditMode = false;
    this.studentData = {} as Student;
    console.log("generando el reset")
  }

  // UI Event Handlers

  onEditItem(element: Student) {
    this.isEditMode = true;
    this.studentData = element;
    console.log("METODO ONEDIT ITEM")

  }

  onDeleteItem(element: Student) {
    this.deleteStudent(element.id);
    console.log("METODO ondelete ITEM")
  }

  onCancelEdit() {
    this.resetEditState();
    this.getAllStudents();
    console.log("METODO CANCELEDIT ITEM")
  }

  onStudentAdded(element: Student) {
    this.studentData = element;

    this.createStudent();
    this.resetEditState();
    console.log("METODO STUDENT ADDED ITEM")
  }

  onStudentUpdated(element: Student) {
    this.studentData = element;
    this.updateStudent();
    this.resetEditState();
    console.log("METODO STUDENT UPDATED ITEM")
  }

  // CRUD Actions

  private getAllStudents() {
    this.studentService.getAll().subscribe((response: any) => {
      this.dataSource.data = response
      console.log("aca esta pidiendo el get")
    });
  };

  private createStudent() {
    this.studentService.create(this.studentData).subscribe((response: any) => {
      this.dataSource.data.push({...response});
      this.dataSource.data = this.dataSource.data.map((student: Student) => {
        console.log("esta creando un user ")
        return student;

      });
    });
  };

  private updateStudent() {
    let studentToUpdate = this.studentData;
    this.studentService.update(this.studentData.id, studentToUpdate).subscribe((response: any) => {
      this.dataSource.data = this.dataSource.data.map((student: Student) => {
        if (student.id === response.id) {
          return response;
          console.log("esta actualizando un user ")

        }
        return student;
      });
    });
  };

  private deleteStudent(studentId: number) {
    this.studentService.delete(studentId).subscribe(() => {
      this.dataSource.data = this.dataSource.data.filter((student: Student) => {
        return student.id !== studentId ? student : false;
        console.log("esta borrando un user ")

      });
    });
  };

// Angular Lifecycle Hooks

  ngOnInit(): void {
    this.getAllStudents();
  }

  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

}
