import { SingUpEntity } from './sing-up.entity';

describe('SingUpEntity', () => {
  it('should create an instance', () => {
    expect(new SingUpEntity()).toBeTruthy();
  });
});
