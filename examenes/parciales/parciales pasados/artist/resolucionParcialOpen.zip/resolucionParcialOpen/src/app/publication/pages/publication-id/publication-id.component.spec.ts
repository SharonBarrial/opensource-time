import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PublicationIdComponent } from './publication-id.component';

describe('PublicationIdComponent', () => {
  let component: PublicationIdComponent;
  let fixture: ComponentFixture<PublicationIdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PublicationIdComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PublicationIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
