import {AfterViewInit, Component, OnInit, ViewChild} from '@angular/core';
import {Participant} from "../../model/participant/participant.entity";
import {MatTableDataSource} from "@angular/material/table";
import {MatPaginator} from "@angular/material/paginator";
import {MatSort} from "@angular/material/sort";
import {ParticipantsService} from "../../services/api-participant/participants.service";
import {Center} from "../../model/center/center.entity";
import {CentersService} from "../../services/api-center/centers.service";

@Component({
  selector: 'app-records-for-marathon-id',
  templateUrl: './records-for-marathon-id.component.html',
  styleUrl: './records-for-marathon-id.component.css'
})
export class RecordsForMarathonIdComponent implements OnInit, AfterViewInit {

  dataSource!: MatTableDataSource<any>;
  participantsData: Participant;
  centerSource!: MatTableDataSource<any>;
  centersData: Center;
  displayedColumns: string[] = ['id', 'lastName', 'centerName', 'ranking', 'recordTime'];
  @ViewChild(MatPaginator, {static: false}) paginator!: MatPaginator;
  @ViewChild(MatSort, {static: false}) sort!: MatSort;

  constructor(private participantService: ParticipantsService, private centerService: CentersService) {
    this.participantsData = {} as Participant;
    this.dataSource = new MatTableDataSource<any>();

    this.centersData = {} as Center;
    this.centerSource = new MatTableDataSource<any>();
  }

  // CRUD Actions

  private getAllCenters() {
    this.centerService.getAll().subscribe((centersResponse: any) => {
      this.centerSource.data = centersResponse;
    });
  }
  private getAllParticipants() {
    this.participantService.getAll().subscribe((participantsResponse: any) => {
      this.dataSource.data = participantsResponse.filter((participant: Participant) => participant.ranking === 1)
        .map((participant: Participant) => {
          const center = this.centerSource.data.find((center: any) => center.id === participant.centerId);
          if (center) {
            participant.centerName = center.name; // Corregir aquí
          }
          return participant;
        });
    });
  }

// Angular Lifecycle Hooks

  ngOnInit(): void {
    this.getAllCenters();
    this.getAllParticipants();


  }
  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }


}
