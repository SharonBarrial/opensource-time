import { MentorEntity } from './mentor.entity';

describe('MentorEntity', () => {
  it('should create an instance', () => {
    expect(new MentorEntity()).toBeTruthy();
  });
});
