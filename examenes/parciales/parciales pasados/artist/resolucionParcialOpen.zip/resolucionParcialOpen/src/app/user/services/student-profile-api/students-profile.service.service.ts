import { Injectable } from '@angular/core';
import {BaseService} from "../../../shared/services/base.service";
import {HttpClient} from "@angular/common/http";
import {catchError, retry} from "rxjs";
import {Publication} from "../../model/publications/publication.entity";

@Injectable({
  providedIn: 'root'
})
export class StudentsProfileService extends BaseService<Publication>{

  constructor(http: HttpClient) {
    super(http);
    this.resourceEndpoint = '/studentprofiles';
  }

  getStudentProfileId(id: number){
    return this.http.get(`${this.resourcePath()}/${id}`, this.httpOptions)
      .pipe(retry(2), catchError(this.handleError));
  }

}
