import { Component } from '@angular/core';

@Component({
  selector: 'app-toolbar-content',
  templateUrl: './toolbar-content.component.html',
  styleUrls: ['./toolbar-content.component.css'] // Cambiar styleUrl a styleUrls
})
export class ToolbarContentComponent {
  options = [
    { path: '/home', title: 'Home'},
    { path: '/learning/students', title: 'Students'},
    { path: '/about', title: 'About'},
    { path: '/participants', title: 'Participants'},
    { path: '/records', title: 'Records'}
  ]
}
