import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FileUploadApiServiceService {

  constructor() { }

  async submitImage(nombre: string, imagen64: any) {
    try {
      // Aquí puedes escribir la lógica para enviar la imagen a tu servidor local
      // Por ejemplo, podrías usar una petición HTTP POST a una ruta en tu servidor que maneje la carga de imágenes
      const response = await fetch('http://localhost:3000/upload-image', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ nombre, imagen64 })
      });

      if (response.ok) {
        const responseData = await response.json();
        console.log(responseData);
        // En este punto, puedes manejar la respuesta de tu servidor como lo desees
        // Por ejemplo, si tu servidor devuelve la URL de la imagen, puedes devolverla aquí
        return responseData.url;
      } else {
        console.error('Error al cargar la imagen:', response.statusText);
        return null;
      }
    } catch (error) {
      console.error('Error al cargar la imagen:', error);
      return null;
    }
  }
}
