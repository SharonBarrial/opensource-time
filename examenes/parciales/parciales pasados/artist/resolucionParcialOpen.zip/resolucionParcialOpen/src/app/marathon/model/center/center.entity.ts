export class Center {
  id: number;
  centerName: string;

  constructor() {
    this.id = 1;
    this.centerName = '';
  }
}
