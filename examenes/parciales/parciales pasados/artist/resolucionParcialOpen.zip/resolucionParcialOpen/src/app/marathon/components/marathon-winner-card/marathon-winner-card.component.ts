import {Component, OnInit} from '@angular/core';
import {ParticipantsService} from "../../services/api-participant/participants.service";
import {Participant} from "../../model/participant/participant.entity";

@Component({
  selector: 'app-marathon-winner-card',
  templateUrl: './marathon-winner-card.component.html',
  styleUrl: './marathon-winner-card.component.css'
})
export class MarathonWinnerCardComponent implements OnInit{
    student= new Participant()
  constructor(private participantApi:ParticipantsService) {
  }

  ngOnInit(): void {
    this.participantApi.getAll().subscribe(
      (data: any) => {
        // Ordenar los datos en función del atributo recordTime
        data.sort((a: any, b: any) => {
          // Convertir las strings de recordTime a objetos Date para comparar
          const timeA = this.stringToDate(a.recordTime).getTime(); // Obtener el valor en milisegundos
          const timeB = this.stringToDate(b.recordTime).getTime(); // Obtener el valor en milisegundos
          return timeA - timeB;
        });

        // Seleccionar el primer elemento (el que tiene el menor recordTime)
        this.student = data[0];

        console.log(this.student);
      }
    );
  }
  stringToDate(timeString: string): Date {
    const [hours, minutes, seconds] = timeString.split(':').map(Number);
    return new Date(0, 0, 0, hours, minutes, seconds);
  }

}
