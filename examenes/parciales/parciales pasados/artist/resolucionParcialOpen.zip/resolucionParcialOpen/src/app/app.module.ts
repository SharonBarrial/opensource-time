import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatToolbarModule } from '@angular/material/toolbar';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './public/pages/home/home.component';
import { AboutComponent } from './public/pages/about/about.component';
import { PageNotFoundComponent } from './public/pages/page-not-found/page-not-found.component';
import { StudentCreateAndEditComponent } from './learning/components/student-create-and-edit/student-create-and-edit.component';
import { StudentManagementComponent } from './learning/pages/student-management/student-management.component';
import { ToolbarContentComponent } from './public/components/toolbar-content/toolbar-content.component';
import { SearchContentComponent } from './public/components/search-content/search-content.component';
import { MarathonGridComponent } from './marathon/components/marathon-grid/marathon-grid.component';
import { MarathonCardComponent } from './marathon/components/marathon-card/marathon-card.component';
import { MarathonWinnerCardComponent } from './marathon/components/marathon-winner-card/marathon-winner-card.component';
import { ParticipantsComponent } from './marathon/pages/participants/participants.component';
import { RecordsForMarathonIdComponent } from './marathon/pages/records-for-marathon-id/records-for-marathon-id.component';
import { RegisterManagerComponent } from './user/components/register-manager/register-manager.component';
import { LoginManagerComponent } from './user/components/login-manager/login-manager.component';
import { StudendsProfileComponent } from './user/components/studends-profile/studends-profile.component';
import { MainComponent } from './publication/pages/main/main.component';
import { CardPublicationComponentsComponent } from './publication/components/card-publication-components/card-publication-components.component';
import {CreatePostComponent} from "./publication/pages/create-post/create-post.component";
import {AngularFireModule} from "@angular/fire/compat";
import {MatSlideToggle} from "@angular/material/slide-toggle";
import {PublicationIdComponent} from "./publication/pages/publication-id/publication-id.component";

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    PageNotFoundComponent,
    StudentCreateAndEditComponent,
    StudentManagementComponent,
    ToolbarContentComponent,
    SearchContentComponent,
    MarathonGridComponent,
    MarathonCardComponent,
    MarathonWinnerCardComponent,
    ParticipantsComponent,
    RecordsForMarathonIdComponent,
    RegisterManagerComponent,
    LoginManagerComponent,
    LoginManagerComponent,
    StudendsProfileComponent,
    MainComponent,
    CardPublicationComponentsComponent,
    CreatePostComponent,
    PublicationIdComponent


  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatCardModule,
    MatDividerModule,
    MatFormFieldModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatSelectModule,
    MatSortModule,
    MatTableModule,
    MatToolbarModule,
    AppRoutingModule,
    AngularFireModule,
    MatSlideToggle
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
