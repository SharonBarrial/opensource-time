import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CardPublicationComponentsComponent } from './card-publication-components.component';

describe('CardPublicationComponentsComponent', () => {
  let component: CardPublicationComponentsComponent;
  let fixture: ComponentFixture<CardPublicationComponentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CardPublicationComponentsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CardPublicationComponentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
