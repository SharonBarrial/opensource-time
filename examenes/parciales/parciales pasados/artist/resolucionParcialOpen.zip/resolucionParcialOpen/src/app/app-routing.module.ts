import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {HomeComponent} from "./public/pages/home/home.component";
import {AboutComponent} from "./public/pages/about/about.component";
import {PageNotFoundComponent} from "./public/pages/page-not-found/page-not-found.component";
import {StudentManagementComponent} from "./learning/pages/student-management/student-management.component";
import {ParticipantsComponent} from "./marathon/pages/participants/participants.component";
import {
  RecordsForMarathonIdComponent
} from "./marathon/pages/records-for-marathon-id/records-for-marathon-id.component";
import {RegisterManagerComponent} from "./user/components/register-manager/register-manager.component";
import {LoginManagerComponent} from "./user/components/login-manager/login-manager.component";
import {StudendsProfileComponent} from "./user/components/studends-profile/studends-profile.component";
import {MainComponent} from "./publication/pages/main/main.component";
import {CreatePostComponent} from "./publication/pages/create-post/create-post.component";
import {PublicationIdComponent} from "./publication/pages/publication-id/publication-id.component";
import {CommonModule} from "@angular/common";

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'about', component: AboutComponent },
  { path: 'main', component: MainComponent },
  { path: 'learning/students', component: StudentManagementComponent },
  { path: 'create-post', component: CreatePostComponent },
  { path: 'participants', component: ParticipantsComponent },
  { path: 'records', component: RecordsForMarathonIdComponent },
  { path: 'register', component: RegisterManagerComponent },
  { path: 'student-profile/2912', component: StudendsProfileComponent},
  { path: 'publication/:id', component: PublicationIdComponent },
  { path: 'studentprofiles/:id', component: PublicationIdComponent },

  { path: 'login', component: LoginManagerComponent },
  { path: '', redirectTo: 'home', pathMatch: 'full'},
  { path: '**', component: PageNotFoundComponent },


];

@NgModule({
  imports: [
    RouterModule.forRoot(routes),
    CommonModule,
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
