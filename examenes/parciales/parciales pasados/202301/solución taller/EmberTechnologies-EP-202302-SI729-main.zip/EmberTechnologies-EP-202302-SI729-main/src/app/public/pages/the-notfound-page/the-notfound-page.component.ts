import { Component } from '@angular/core';
import {RouterLink} from "@angular/router";

@Component({
  selector: 'app-the-notfound-page',
  standalone: true,
  imports: [
    RouterLink
  ],
  templateUrl: './the-notfound-page.component.html',
  styleUrl: './the-notfound-page.component.css'
})
export class TheNotfoundPageComponent {

}
