import { BundleEntity } from './bundle.entity';

describe('BundleEntity', () => {
  it('should create an instance', () => {
    expect(new BundleEntity()).toBeTruthy();
  });
});
