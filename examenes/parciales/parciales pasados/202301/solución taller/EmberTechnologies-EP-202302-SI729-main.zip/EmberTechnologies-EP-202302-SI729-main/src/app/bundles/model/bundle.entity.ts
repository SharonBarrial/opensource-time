export class Bundle {
  id:any;
  title:any;
  photoUrl:any;
  price:any;
  rating:any;

  constructor(id:any, title:any, photoUrl:any, price:any, rating:any) {
    this.id = id;
    this.title = title;
    this.photoUrl = photoUrl;
    this.price = price;
    this.rating = rating;
  }

}
