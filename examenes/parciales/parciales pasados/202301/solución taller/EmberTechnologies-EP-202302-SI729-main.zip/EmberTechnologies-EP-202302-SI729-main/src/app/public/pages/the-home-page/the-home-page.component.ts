import { Component } from '@angular/core';

@Component({
  selector: 'app-the-home-page',
  standalone: true,
  imports: [],
  templateUrl: './the-home-page.component.html',
  styleUrl: './the-home-page.component.css'
})
export class TheHomePageComponent {

}
