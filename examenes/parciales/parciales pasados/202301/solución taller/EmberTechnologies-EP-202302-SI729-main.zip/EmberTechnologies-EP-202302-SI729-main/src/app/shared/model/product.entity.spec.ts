import { ProductEntity } from './product.entity';

describe('ProductEntity', () => {
  it('should create an instance', () => {
    expect(new ProductEntity()).toBeTruthy();
  });
});
