# Upc2401si729eau20221b127

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 17.3.6.

## Application Information

This application shows the mental state exam information of all patients.

## Description

This application is a simple web application that shows the mental state exam information of all patients.
It uses the Angular framework to create the user interface and the Angular Material library to style the user interface. 
Also, it contains a server directory that has the db.json with all the data through json-server.

## Author

Salvador Antonio Salinas Torres u20221b127
