# Upc2401si729eau20201b298

Hartford Institute for Geriatric Nursing (HIGN) - Mental Health Evaluation

HIGN is a web application that allows users to view their information about their mental state evaluations.

This project was generated with Angular CLI version 17.3.6.

# Author
The author is: 'Miguel Angel Ybañez Esquerre- U20201b298' - The application was built for educational purposes

I am software engineering student at UPC University. I'm currently
cursing the 8th cycle of the career.

Run ng serve for a dev server. Navigate to http://localhost:4200/. The application will automatically reload if you change any of the source files.

# Code scaffolding
Run ng generate component component-name to generate a new component. You can also use ng generate directive|pipe|service|class|guard|interface|enum|module.

# References
Further help
To get more help on the Angular CLI use ng help or go check out the Angular CLI Overview and Command Reference page.
