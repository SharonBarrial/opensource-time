import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import {TheHeaderContentComponent} from "./public/components/the-header-content/the-header-content.component";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, TheHeaderContentComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'upc2401si729eau20201b298';
}
