export interface Examiner {
  "id": number,
  "firstName": string,
  "lastName": string,
  "nationalProviderIdentifier":string
}
