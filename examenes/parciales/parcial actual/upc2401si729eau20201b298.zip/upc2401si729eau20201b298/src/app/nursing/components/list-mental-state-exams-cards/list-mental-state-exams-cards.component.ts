import {Component, OnInit} from '@angular/core';
import {MentalStateExamCardComponent} from "../mental-state-exam-card/mental-state-exam-card.component";
import {MentalStateExam} from "../../models/mental-state-exams.model";
import {MentalStateExamService} from "../../services/mental-state-exam.service";

@Component({
  selector: 'app-list-mental-state-exams-cards',
  standalone: true,
  imports: [
    MentalStateExamCardComponent
  ],
  templateUrl: './list-mental-state-exams-cards.component.html',
  styleUrl: './list-mental-state-exams-cards.component.css'
})
export class ListMentalStateExamsCardsComponent implements OnInit{
  exams!: MentalStateExam[];
  constructor(private mentalStateExamService: MentalStateExamService) {
  }
  ngOnInit() {
    this.getExams()
  }
  getExams(){
    this.mentalStateExamService.getAll().subscribe(response => {
      this.exams = response;
    });
  }
}
