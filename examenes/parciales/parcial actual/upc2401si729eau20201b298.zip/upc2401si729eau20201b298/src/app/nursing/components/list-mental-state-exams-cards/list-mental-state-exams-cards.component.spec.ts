import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListMentalStateExamsCardsComponent } from './list-mental-state-exams-cards.component';

describe('ListMentalStateExamsCardsComponent', () => {
  let component: ListMentalStateExamsCardsComponent;
  let fixture: ComponentFixture<ListMentalStateExamsCardsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ListMentalStateExamsCardsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ListMentalStateExamsCardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
