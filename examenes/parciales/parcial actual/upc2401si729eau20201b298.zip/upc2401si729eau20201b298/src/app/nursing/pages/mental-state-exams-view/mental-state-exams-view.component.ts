import { Component } from '@angular/core';
import {
  ListMentalStateExamsCardsComponent
} from "../../components/list-mental-state-exams-cards/list-mental-state-exams-cards.component";

@Component({
  selector: 'app-mental-state-exams-view',
  standalone: true,
  imports: [
    ListMentalStateExamsCardsComponent
  ],
  templateUrl: './mental-state-exams-view.component.html',
  styleUrl: './mental-state-exams-view.component.css'
})
export class MentalStateExamsViewComponent {

}
