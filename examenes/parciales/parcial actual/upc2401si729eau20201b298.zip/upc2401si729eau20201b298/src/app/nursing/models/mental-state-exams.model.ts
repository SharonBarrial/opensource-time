export interface MentalStateExam {
  "id": number,
  "patientId": number,
  "examinerId": number,
  "examDate": string,
  "orientationScore": number,
  "registrationScore": number,
  "attentionAndCalculationScore": number,
  "recallScore": number,
  "languageScore": number
}
