import {Component, Input, OnInit} from '@angular/core';
import {MatCardModule} from '@angular/material/card';
import {Patient} from "../../models/patient.model";
import {PatientService} from "../../services/patient.service";
import {Examiner} from "../../models/examiner";
import {ExaminerService} from "../../services/examiner.service";
import {MentalStateExam} from "../../models/mental-state-exams.model";
import {MentalStateExamService} from "../../services/mental-state-exam.service";

@Component({
  selector: 'app-mental-state-exam-card',
  standalone: true,
  imports: [MatCardModule],
  templateUrl: './mental-state-exam-card.component.html',
  styleUrl: './mental-state-exam-card.component.css'
})
export class MentalStateExamCardComponent implements OnInit{
  Patient!: Patient;
  Examiner!: Examiner;
  @Input() MentalStateExams!: MentalStateExam;

  constructor(private patientService: PatientService,private examinerService: ExaminerService, private mentalStateExamService: MentalStateExamService) {
    this.Patient = {} as Patient;
    this.Examiner = {} as Examiner;
    this.MentalStateExams={} as MentalStateExam;
  }
  ngOnInit() {
    this.getPatient()
    this.getExaminer()
  }

  getPatient(){
    this.patientService.getOne(this.MentalStateExams.patientId).subscribe(patient => {
      this.Patient = patient;
    })
  }

  getExaminer(){
    this.examinerService.getOne(this.MentalStateExams.examinerId).subscribe(examiner => {
      this.Examiner = examiner;
    })
  }
}
