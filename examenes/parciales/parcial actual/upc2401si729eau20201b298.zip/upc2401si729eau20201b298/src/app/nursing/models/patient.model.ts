export interface Patient {
  "id": number,
  "firstName": string,
  "lastName": string,
  "photoUrl": string,
  "birthDate": string
}
