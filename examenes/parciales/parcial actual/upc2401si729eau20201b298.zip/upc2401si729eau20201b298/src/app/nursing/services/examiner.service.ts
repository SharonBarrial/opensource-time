import { Injectable } from '@angular/core';
import {BaseService} from "../../shared/services/base.service";
import {HttpClient} from '@angular/common/http';
import {Examiner} from "../models/examiner";

@Injectable({
  providedIn: 'root'
})
export class ExaminerService extends BaseService<Examiner>{

  constructor(http: HttpClient) {

    super(http);
    this.resourceEndpoint = 'examiners';

  }
}
