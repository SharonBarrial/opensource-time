import { Routes } from '@angular/router';
import {PageNotFoundComponent} from "./public/pages/page-not-found/page-not-found.component";
import {TheHomeViewComponent} from "./public/pages/the-home-view/the-home-view.component";
import {MentalStateExamsViewComponent} from "./nursing/pages/mental-state-exams-view/mental-state-exams-view.component";

export const routes: Routes = [
  {path: "home", component:TheHomeViewComponent},
  {path: "nursing/mental-state-exams",  component: MentalStateExamsViewComponent},
  {path: "", redirectTo: "home", pathMatch: "full"},
  {path: "**",  component: PageNotFoundComponent},
];
