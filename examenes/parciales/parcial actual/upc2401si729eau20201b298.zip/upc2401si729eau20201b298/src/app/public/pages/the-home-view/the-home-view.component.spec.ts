import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TheHomeViewComponent } from './the-home-view.component';

describe('TheHomeViewComponent', () => {
  let component: TheHomeViewComponent;
  let fixture: ComponentFixture<TheHomeViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TheHomeViewComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(TheHomeViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
