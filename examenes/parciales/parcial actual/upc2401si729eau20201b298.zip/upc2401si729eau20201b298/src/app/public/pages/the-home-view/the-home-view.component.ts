import {Component, OnInit, ViewChild} from '@angular/core';
import {HttpClientModule, HttpClient} from "@angular/common/http";
import {Title} from "@angular/platform-browser";
import {Router} from "@angular/router";
import {TheHeaderContentComponent} from "../../components/the-header-content/the-header-content.component";

@Component({
  selector: 'app-the-home-view',
  standalone: true,
  imports: [
    HttpClientModule
  ],
  templateUrl: './the-home-view.component.html',
  styleUrl: './the-home-view.component.css'
})
export class TheHomeViewComponent implements OnInit{
  title: string = "hola";
  @ViewChild(TheHeaderContentComponent) headerContent!: TheHeaderContentComponent;
  selectedLanguage!: string;

  constructor(private titleService: Title) {

  }

  ngOnInit() {
    this.headerContent.languageChanged.subscribe((language: string) => {
      this.selectedLanguage = language;
      this.onLanguageChange(); // Llamar a la función deseada cuando cambie el idioma
    });
  }

  onLanguageChange() {
    console.log("Language changed:", this.selectedLanguage);
    if (this.selectedLanguage == "es") {this.titleService.setTitle($localize`${this.title}`)}
  }
}
