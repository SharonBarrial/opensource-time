import {Component, EventEmitter, Output} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatToolbarModule } from '@angular/material/toolbar';
import { RouterModule } from '@angular/router';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
@Component({
  selector: 'app-the-header-content',
  standalone: true,
  imports: [MatButtonModule,MatToolbarModule,RouterModule,MatButtonToggleModule],
  templateUrl: './the-header-content.component.html',
  styleUrl: './the-header-content.component.css'
})
export class TheHeaderContentComponent {
  selectedLanguage!: string;
  @Output() languageChanged: EventEmitter<string> = new EventEmitter<string>();

  constructor() {}

  onLanguageChange(language: string) {
    this.selectedLanguage = language;
    this.languageChanged.emit(language); // Emitir el evento cuando cambie el idioma
  }
}
