package io.newschool.platform.u201919295;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Si729pc2u201919295ApplicationTests {

	@Test
	void contextLoads() {
	}

}
