package io.newschool.platform.u201919295;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class Si729pc2u201919295Application {

	public static void main(String[] args) {
		SpringApplication.run(Si729pc2u201919295Application.class, args);
	}

}
