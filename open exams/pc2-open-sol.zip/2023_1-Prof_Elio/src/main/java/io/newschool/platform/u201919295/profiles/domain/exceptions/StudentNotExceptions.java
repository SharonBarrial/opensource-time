package io.newschool.platform.u201919295.profiles.domain.exceptions;

public class StudentNotExceptions extends RuntimeException{
     public StudentNotExceptions(){
        super("Students not found");
    }
}
