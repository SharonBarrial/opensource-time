package io.newschool.platform.u201919295.profiles.domain.model.queries;

public record GetStudentByIdQuery(Long StudentId){
}
