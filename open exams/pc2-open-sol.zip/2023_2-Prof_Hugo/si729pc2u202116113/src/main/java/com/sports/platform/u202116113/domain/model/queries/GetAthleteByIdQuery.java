package com.sports.platform.u202116113.domain.model.queries;

public record GetAthleteByIdQuery(Long id) {

}
