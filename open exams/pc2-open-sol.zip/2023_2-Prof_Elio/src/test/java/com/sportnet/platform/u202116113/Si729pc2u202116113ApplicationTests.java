package com.sportnet.platform.u202116113;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Si729pc2u202116113ApplicationTests {

    @Test
    void contextLoads() {
    }

}
