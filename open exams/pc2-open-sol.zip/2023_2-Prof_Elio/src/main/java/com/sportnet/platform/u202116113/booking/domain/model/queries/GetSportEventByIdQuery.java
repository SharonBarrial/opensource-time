package com.sportnet.platform.u202116113.booking.domain.model.queries;

public record GetSportEventByIdQuery(Long id) {
}
