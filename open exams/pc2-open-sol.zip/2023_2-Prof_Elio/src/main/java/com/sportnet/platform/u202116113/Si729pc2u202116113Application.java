package com.sportnet.platform.u202116113;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Si729pc2u202116113Application {

    public static void main(String[] args) {
        SpringApplication.run(Si729pc2u202116113Application.class, args);
    }

}
