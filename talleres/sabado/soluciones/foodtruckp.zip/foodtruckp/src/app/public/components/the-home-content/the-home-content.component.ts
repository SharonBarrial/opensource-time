import {Component, OnInit} from '@angular/core';
import {MatCardModule} from '@angular/material/card';
import {Router} from "@angular/router";
import {FoodTruckService} from "../../../FoodTrucks/services/food-truck.service";
@Component({
  selector: 'app-the-home-content',
  standalone: true,
  imports: [MatCardModule],
  templateUrl: './the-home-content.component.html',
  styleUrl: './the-home-content.component.css'
})
export class TheHomeContentComponent implements OnInit {
  foodTrackCount=0;
  constructor(private foodTruckService: FoodTruckService) {}

  ngOnInit() {
    this.foodTruckService.getAll().subscribe(response => {
      this.foodTrackCount = response.length;
    });

  }
}
