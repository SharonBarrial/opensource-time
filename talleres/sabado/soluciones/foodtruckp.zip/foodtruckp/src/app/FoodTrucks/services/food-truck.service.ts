import { Injectable } from '@angular/core';
import {BaseService} from "../../shared/services/base.service";
import {HttpClient} from "@angular/common/http";

import {FoodTruck} from "../models/food-truck.model";

@Injectable({
  providedIn: 'root'
})
export class FoodTruckService extends BaseService<FoodTruck>{

  constructor(http: HttpClient) {
    super(http);
    this.resourceEndpoint = 'food-trucks';
  }

  checkIfExists(brand:string, email:string) {
    return this._http.get<any>(`${this.resourcePath()}/?brandName=${brand}&email=${email}`)
  }
}
