export class FoodTruck {
  id: string;
  ownerFirstName: string;
  ownerLastName: string;
  brandName: string;
  email: string;
  address: string;
  websiteUrl: string;
  menuUrl: string;

  constructor(id: string, ownerFirstName: string, ownerLastName: string, brandName: string, email: string, address: string, websiteUrl: string= "", menuUrl: string = "") {
    this.id = id;
    this.ownerFirstName = ownerFirstName;
    this.ownerLastName = ownerLastName;
    this.brandName = brandName;
    this.email = email;
    this.address = address;
    this.websiteUrl = websiteUrl;
    this.menuUrl = menuUrl;
  }
}
