import { Component } from '@angular/core';
import {FormControl, FormGroup, FormsModule, NgForm, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatCardModule} from '@angular/material/card';
import { FoodTruck} from "../../models/food-truck.model";
import {FoodTruckService} from "../../services/food-truck.service";
import {MatButton} from "@angular/material/button";
import {Router} from "@angular/router";

@Component({
  selector: 'app-register-food-truck',
  standalone: true,
  imports: [MatCardModule,MatFormFieldModule, MatInputModule, ReactiveFormsModule, FormsModule, MatButton],
  templateUrl: './register-food-truck.component.html',
  styleUrl: './register-food-truck.component.css'
})
export class RegisterFoodTruckComponent {
  foodTruck: FormGroup;

  constructor(private foodTruckService: FoodTruckService, private router: Router) {
    this.foodTruck = new FormGroup({
      ownerFirstName: new FormControl("", Validators.required),
      ownerLastName: new FormControl("", Validators.required),
      brandName: new FormControl("", Validators.required),
      email: new FormControl("", [Validators.required, Validators.email]),
      address: new FormControl(""),
      websiteUrl: new FormControl(""),
      menuUrl: new FormControl(""),
    })
  }

  submitForm() {
    if (this.foodTruck.valid) {
      console.log(this.foodTruck.value);
      const foodTruck:FoodTruck = new FoodTruck(
        "",
        this.foodTruck.value.ownerFirstName,
        this.foodTruck.value.ownerLastName,
        this.foodTruck.value.brandName,
        this.foodTruck.value.email,
        this.foodTruck.value.address,
        this.foodTruck.value.websiteUrl,
        this.foodTruck.value.menuUrl
        );
      this.foodTruckService.checkIfExists(this.foodTruck.value.brandName, this.foodTruck.value.email).subscribe(exist=>{
        console.log(exist);
        if (exist.length>0){
          console.log("esa marca y correo ya existen")
        } else {
          this.registerFood(foodTruck)
        }
      });
    } else {
      console.log("Formulario inválido");
    }
  }

  registerFood(foodTruck: FoodTruck) {
      this.foodTruckService.post(foodTruck).subscribe(response => {
        this.router.navigate(['/home']);
      })
  }
  cancel() {
    this.foodTruck.reset(); // Reinicia el formulario
    this.router.navigate(['/home']);
  }
}
