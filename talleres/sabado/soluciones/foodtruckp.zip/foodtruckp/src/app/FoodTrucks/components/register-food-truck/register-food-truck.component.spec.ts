import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterFoodTruckComponent } from './register-food-truck.component';

describe('RegisterFoodTruckComponent', () => {
  let component: RegisterFoodTruckComponent;
  let fixture: ComponentFixture<RegisterFoodTruckComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RegisterFoodTruckComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(RegisterFoodTruckComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
